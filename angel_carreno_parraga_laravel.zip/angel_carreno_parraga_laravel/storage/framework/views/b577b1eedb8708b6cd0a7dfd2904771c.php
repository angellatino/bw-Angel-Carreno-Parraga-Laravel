<!DOCTYPE html>
<html>
<head>
    <title>Football Transfer Rumors</title>
    
    <link href="https://maxcdn.bootstrapcdn.com/bootstrap/4.0.0/css/bootstrap.min.css" rel="stylesheet">
</head>
<body>
    <div class="container">
        <h1>Football Transfer Rumors</h1>
        <?php if(auth()->guard()->check()): ?>
            <a href="<?php echo e(route('posts.create')); ?>" class="btn btn-primary">Add New Rumor</a>
        <?php endif; ?>
        <div class="row">
            <?php $__currentLoopData = $posts; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $post): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <div class="col-md-4">
                    <div class="card">
                        <?php if($post->cover_image): ?>
                            <img src="<?php echo e(asset('storage/' . $post->cover_image)); ?>" class="card-img-top" alt="<?php echo e($post->title); ?>">
                        <?php endif; ?>
                        <div class="card-body">
                            <h5 class="card-title"><?php echo e($post->title); ?></h5>
                            <p class="card-text"><?php echo e(Str::limit($post->content, 100)); ?></p>
                            <a href="<?php echo e(route('posts.show', $post->id)); ?>" class="btn btn-primary">Read More</a>
                        </div>
                    </div>
                </div>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </div>
    </div>
</body>
</html>
<?php /**PATH C:\xampp\htdocs\Backend\bw Angel Carreno Parraga Laravel\angel_carreno_parraga_laravel\resources\views/posts/index.blade.php ENDPATH**/ ?>